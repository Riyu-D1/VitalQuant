# VitalQ v2 fabrication and assembly notes

## Release basis

- Source board: `fix_v9/vitalq_v2.kicad_pcb`, KiCad 10.0.4 (derived from fix_v8; all earlier revisions untouched).
- fix_v18 deltas vs fix_v16: **charger power path added (load-sharing)** — new Q6 (AO3401A P-ch MOSFET, SOT-23, LCSC C15127) replaces the R93 0-ohm link between VBAT and VBAT_SYS: drain(pin3)=VBAT, source(pin2)=VBAT_SYS, gate(pin1)=VBUS; D33 (1N5819WS, SOD-323, LCSC C191023) anode=VBUS cathode=VBAT_SYS feeds the system rail from USB when present; R123 (100k 0402, LCSC C25741) pulls the gate net to GND when VBUS is absent. **R93 is now DNP** — VBAT and VBAT_SYS meet only through Q6. Rationale: an ~80 mA system load on the charger OUT node prevented charge termination/timeout behaviour in fix_v16 (see COMPSIM_REPORT.md). **Board outline enlarged: east edge extended +5.6 mm** — new tab x 48->53.6 mm over y 20->29.9 mm only (overall board now 55.6 x 75.0 mm; all mounting holes, connectors and every pre-existing track/via/zone/footprint are unchanged — verified object-level diff: only R93 (dnp flag) and the east-edge segment differ, everything else is purely additive). New copper: 8 vias, 26 segments on F.Cu/In3/In5. VBUS reaches the tab via a new In3.Cu route tapped at via (27.93,-2.23). Fab zip: `VitalQ_v2_fixv18_fabrication.zip`.
- fix_v16 deltas vs fix_v15: **PCB value fields synced** — C9 4.7u->10u, C63/C79 100n->1u footprint value text now matches schematic (R7 had updated sch+BOM/CPL only; F.Fab text layer only, zero copper/mask/paste/silk change — regenerated Gerbers verified content-identical). Fab zip: `VitalQ_v2_fixv16_fabrication.zip`.
- fix_v15 deltas vs fix_v14: C79 (+3V3_ANA local decap at U6 RX_SUP, C1) 100n -> **1u** (LCSC C14445, Samsung CL05A105KP5NNNC 0402 1uF 10V X5R, in stock) per AFE4900 SBAS857 pin-table requirement of 1uF local decap. C9 (VDD_CP2102 reg output, U5.6) 4.7u -> **10u** (LCSC C307415, Samsung CL05A106MP8NUB8 0402 10uF 10V X5R, in stock) so post-DC-bias effective capacitance meets the CP2102N 4.7uF spec. **C63 (VBUS decap) relocated (26.33,11.96) -> (28.60,3.90) rotated -90deg and revalued 100n -> 1u (same LCSC C14445)** so U2 BQ25170 IN has its required >=1uF bypass within ~1.2 mm of the pin (was 8.6 mm); the freed VBUS/GND stubs at the old site were rejoined/removed (0 unconnected, 0 DRC errors). Gerbers regenerated: only the Top Layer content differs vs fix_v14; inner layers, mask, paste, Edge_Cuts and drill are content-identical (header timestamps only).
- fix_v9 deltas vs fix_v8: **J3 force-sensor contact pads (Pads_FSR: +3V3 / FSR_ADC) moved F.Cu → B.Cu** at board (43.1, 59.85) — pad 1 `+3V3` at (42.0, 59.85), pad 2 `FSR_ADC` at (44.2, 59.85). `+3V3` escapes through a 0.25/0.15 POFV via-in-pad to the In4 +3V3 plane; `FSR_ADC` escapes through a second POFV via-in-pad to a new In1 run landing on via (26.3, 61.895), which joins the existing F.Cu FSR trunk (stub diagonal trimmed, 8 dead J3-feed segments removed). Every non-J3 track, via, pad position and net assignment is **identical to fix_v8** (verified object diff: 0 differences). J3 is a force-sensor pair, not a patient-contact electrode — **no hv rule areas were added**. See `../FIX_REPORT.md`.
- fix_v8 deltas vs fix_v7 (carried forward): **J7 chest-BioZ contact pads moved F.Cu → B.Cu** as a staggered 2×2 array at board x≈1.1–3.6 mm, y≈60.7–62.9 mm. Only the four `BIOZ_*_PAD` nets were rerouted; every non-J7 object is identical to fix_v7. Eight J7 electrode rule areas added, matching the other electrodes' protection scheme.
- Refilled error-level DRC: **0 errors, 0 unconnected, 0 schematic-parity errors** (29 accepted BOM warnings; 105 warnings total, all pre-existing classes — fewer than fix_v8's 107 and fix_v7's 112).
- fix_v6 deltas vs release: same copper as fix_v4/fix_v5 (8,871 tracks/vias byte-identical). BOM/value changes only: **R61, R107, R108 DNP** (join pre-existing J13, R104, R105 — six DNP refs total, footprints retained); R88 -> **150 ohm** (C25082); R51 -> **150k** (C25755); R73 -> **10k** (C25744); R19/R20/R21/R22 -> **2.2k** (C25879). CPL is 248 placements. See `../FIX_REPORT.md`.
- fix_v4 deltas vs release: D10 site-fit pads and D12 at (15.94, 50.6) as in fix_v3; **R104/R105 restored to DNP** so USB-C feeds only the ESP32 native USB port (CP2102 remains fitted but disconnected from the data lines); the pre-existing `antenna_keepout` zone under U1 was verified copper-free on all 8 layers. CPL is now 251 placements. See `../FIX_REPORT.md`.
- The owner accepted the 29 schematic/PCB BOM-exclusion attribute warnings. They concern J8 and TP1–TP28, not electrical netlist differences.
- The unfiltered report retains warning-level PCB findings of the same accepted classes as earlier fixes. There are no unconnected nets.
- Independent keepout audit from earlier fixes stands; fix_v4 adds no new keepouts (the antenna keepout already existed as a board zone).

## Construction

- **Eight copper layers, FR4, ENIG finish.**
- Board-level nominal thickness is **1.6 mm**. The unchanged detailed stackup below sums to **1.4776 mm** for copper plus dielectric, or **1.53856 mm** including the modeled 0.03048 mm soldermask on each face. This nominal/detail discrepancy is present in the source design. Obtain fabrication-engineering confirmation of the final manufacturable stackup; do not silently substitute a different stackup or change the layer order.
- The v18 outline is 55.6 x 75.0 mm (east tab added, see above). Preserve the supplied outline and every remaining internal creepage slot. The former U-shaped sensor-island slot has intentionally been removed; that region is now solid board.
- Track/gap requirement: at least 0.09 mm. Routed tracks use at least 0.1016 mm; the authorized Q1/Q2/Q4 footprint-internal pad gaps are 0.100 mm with a 0.09 mm scoped rule.
- Hole-to-hole and hole-to-other-net-copper requirements: at least 0.20 mm.
- All vias are through-vias. Use the separate PTH and NPTH drill files. NPTH mounting and Tag-Connect holes remain unplated and open.

| Order | KiCad layer / material | Thickness (mm) |
|---|---|---:|
| 1 | F.Cu — Top Layer | 0.0350 |
| | FR4 prepreg, dielectric 1 | 0.0994 |
| 2 | In1.Cu — Ground Layer 2 | 0.0152 |
| | FR4 core, dielectric 2 | 0.3000 |
| 3 | In2.Cu — Layer 3 | 0.0152 |
| | FR4 prepreg, dielectric 3 | 0.1088 |
| 4 | In3.Cu — Signal Layer 4 | 0.0152 |
| | FR4 core, dielectric 4 | 0.3000 |
| 5 | In4.Cu — Power Layer 5 | 0.0152 |
| | FR4 prepreg, dielectric 5 | 0.1088 |
| 6 | In5.Cu — Signal Layer 6 | 0.0152 |
| | FR4 core, dielectric 6 | 0.3000 |
| 7 | In6.Cu — Ground Layer 7 | 0.0152 |
| | FR4 prepreg, dielectric 7 | 0.0994 |
| 8 | B.Cu — Bottom Layer | 0.0350 |

## Required via-in-pad process

- **POFV / filled, copper-capped and planarized via-in-pad is required**, including the 0.25 mm land / 0.15 mm nominal-hole vias in solderable or electrode lands. Soldermask tenting alone is not an acceptable substitute.
- This specifically includes the authorized U6.E2 via beneath the J8 footprint keepout and the J11.3 electrode via at board coordinates **x=46.8 mm, y=55.3 mm**. The latter is wholly inside its own electrode pad. Both are 0.25/0.15 mm.
- Apply the same filled-and-capped process to all other vias intersecting SMD/BGA lands. Keep exposed electrode contact surfaces planar and ENIG-finished, without an open via hole.
- J8's U6.E2 keepout notch is the exact authorized local exception. The J8/U6 NPTH/courtyard exception was accepted after a conservative minimum NPTH-to-U6-pad clearance of 0.4485 mm was verified.

## Owner-approved partial electrode isolation

- **This board intentionally uses partial, not full-stack, electrode isolation.**
- All 40 `hv_inner` electrode rule areas apply only to **In5.Cu and In6.Cu**, the two inner layers adjacent to the B.Cu skin-electrode side. They no longer apply to In1.Cu through In4.Cu.
- J5/J6/J7/J11/J13 skin-electrode pads are on B.Cu — fix_v8 moved J7's chest-bioimpedance contact pads from F.Cu to B.Cu so all five skin electrodes now face the same side. fix_v9 additionally moved the J3 FSR contact pads to B.Cu; J3 is a force-sensor pad pair (not a patient-contact electrode), so no hv rule areas were added for it. The owner's global bottom-side partial-isolation decision still applies.
- Outer-layer `hv_ownlayer` protection, all other original keepouts, and all remaining creepage slots are retained. Original keepout-report track segments were not rerouted. Only the later PWDN escape was locally adjusted while relocating offending through-vias.
- Own-electrode apertures are limited to that electrode's own via copper. Separate fill-only guards retain the original copper-pour exclusion coverage on In5.Cu/In6.Cu. No cross-electrode aperture was added. J11_CE's authorized own-net aperture follows its via into J11.3; its old aperture was restored.
- U20 and U11 remain at their original positions on their original faces. The schematic/netlist and layer stackup are unchanged.
- DRC and this fabrication package are not a medical/electrical safety certification.

## Assembly data

- `BOM.csv` and `CPL.csv` use JLC column names. Population follows the PCB's exclusion and DNP flags. Integral `vitalq:Pads_*` copper contacts, testpoints, fiducials, mounting holes and the bare Tag-Connect land pattern are not purchased/placed components and are excluded from the assembly CSVs. Their PCB copper remains in the Gerbers.
- LCSC identifiers are populated for every orderable row. The only blank LCSC cells are the two intentional consignments: D12 (`XL0603NRC730`, Sealand 0603 730 nm — no distributor stocks a 700–770 nm emitter ≤0603; see `../FIX_REPORT.md`) U12 (`MLX90632SLD-DCB-100-RE`, JLC global-source C17235844 / Mouser). **R10 update:** schematic now also carries LCSC C5349491 (exact -SP catalog entry); keep consignment/global-source as fallback if C5349491 is unstocked. See `ASSEMBLY_CHECKS.json`.
- CPL coordinates are in millimetres at the same absolute board origin as the Gerbers and drills. KiCad exports Y upward; negative coordinates are intentional. Bottom-side X is not separately mirrored. Do not translate only one file set.
- CPL rotations are the native KiCad footprint rotations modulo 360 degrees. The assembler must review package-specific zero orientation, polarity and bottom-side orientation in the assembly preview; no unsupported part-library rotation corrections have been invented.
- `positions_kicad.csv` is the raw position-export audit file. Use the filtered `CPL.csv` for assembly.
